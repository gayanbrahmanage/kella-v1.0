# Connectors_Video.pretty
This library contains footprints for several video connectors:

- DVI (Digital Visual Interface)
- HDMI (High-Definition Multimedia Interface)
