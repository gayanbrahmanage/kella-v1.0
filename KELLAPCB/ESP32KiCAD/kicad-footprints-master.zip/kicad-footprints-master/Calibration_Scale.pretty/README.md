# Calibration_Scales.pretty

This library houses footprints of measurement scales and grids.
Useful to calibrate home pcb production.
